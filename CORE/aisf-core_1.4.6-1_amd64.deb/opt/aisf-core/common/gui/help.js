// AI Stability Framework(TM) (C)2026 Leonard Rojas, all rights reserved.
// Help page text sizer, as on AISF-WEB: S, M, L scale the root font size, and the
// choice is remembered where the browser allows it.
(function () {
  function stored() {
    try { return localStorage.getItem('font-size'); } catch (e) { return null; }
  }
  function applySize(s) {
    document.documentElement.classList.remove('font-s', 'font-l');
    if (s === 's') document.documentElement.classList.add('font-s');
    if (s === 'l') document.documentElement.classList.add('font-l');
    document.querySelectorAll('.font-btn').forEach(function (btn) {
      btn.setAttribute('aria-pressed', btn.dataset.size === s ? 'true' : 'false');
    });
  }
  applySize(stored() || 'm');
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.font-btn');
    if (!btn) return;
    try { localStorage.setItem('font-size', btn.dataset.size); } catch (err) { /* not kept */ }
    applySize(btn.dataset.size);
  });
})();
